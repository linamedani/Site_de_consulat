<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulat d'Algérie</title>
    <link rel="stylesheet" href="../Css/footer.css">
 
</head>
<body>
 
 
 <!-- Pied de page -->
 <footer>
        <div class="contact-info">
            <p><i class="fas fa-map-marker-alt"></i> 3 Rue d'Alger</p>
            <p><i class="fas fa-phone-alt"></i> +2130546893258</p>
            <p><i class="fas fa-envelope"></i> consulat_algerie@gmail.com</p>
        </div>
        <div class="footer-links">
            <a href="index.php?controller=contact&action=contact">Nous écrire</a>
            <a href="#">Mentions légales</a>
            <a href="#">Gestion de cookies</a>
        </div>
    </footer>
</body>
</html>