<?php
//Need to change when home

$host = 'localhost';
$port = 5432;
$dbname = 'consulat';

$dsn = "pgsql:host=$host;port=$port;dbname=$dbname";

$login = "postgres";
$mdp = 'lina';

?>
